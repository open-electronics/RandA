#!/bin/sh
#export JAVA_HOME="/usr/lib/jvm/jdk-7-oracle-armhf"
export JAVA_HOME="/usr/lib/jvm/jdk-8-oracle-arm-vfp-hflt"
sudo /home/apache-tomcat-7.0.47/bin/shutdown.sh