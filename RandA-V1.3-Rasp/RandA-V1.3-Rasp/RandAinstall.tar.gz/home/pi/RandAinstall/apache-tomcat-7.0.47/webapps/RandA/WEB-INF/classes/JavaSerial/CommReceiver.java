package JavaSerial;

public  interface CommReceiver 
{
	public void newByte(byte by);
	public void newRecord(String rec);
}
