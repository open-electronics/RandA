package ArduIO;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Vector;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import JavaSerial.*;

/**
 * Servlet implementation class SerialIO
 * A bridge from Web Server to Arduino
 * From WEB commands    ---   to Arduino command
 *   open
 *   close
 *   readAll                     PA
 *   readAna An                  RAn
 *   readDig Dn                  RDn
 *   writeDig WDn V               WDn=v
 *   writeAna WAn V              WAn=v
 *   setPin SDn INP|IPL|OUT      SPn=INP|IPL|OUT
 *   
 * 
 */
@WebServlet("/SerialIO")
public class SerialIO extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	SerialComm Comm;
	PrintStream commpr;
	String Port="/dev/ttyS0";
	int Bauds=9600;
	
	CReceiver Receiver=null;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SerialIO() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter outpr=new PrintWriter(response.getWriter());
		String cmd=request.getParameter("cmd");
		if (cmd.equalsIgnoreCase("refresh")) refresh(outpr);
		if (cmd.equalsIgnoreCase("writeser")) writeser(request,outpr);
		if (cmd.equalsIgnoreCase("open")) opencomm(request,outpr);
		if (cmd.equalsIgnoreCase("close")) closecomm(outpr);
		if (cmd.equalsIgnoreCase("readAna")) readAna(request,outpr);
		if (cmd.equalsIgnoreCase("readDig")) readDig(request,outpr);
		if (cmd.equalsIgnoreCase("writeDig")) writeDig(request,outpr);
		if (cmd.equalsIgnoreCase("writeAna")) writeAna(request,outpr);
		if (cmd.equalsIgnoreCase("setPin")) setPin(request,outpr);
		if (cmd.equalsIgnoreCase("readAll")) readAll(outpr);
		if (cmd.equalsIgnoreCase("readAllDigInp")) readAllDigInp(outpr);
		if (cmd.equalsIgnoreCase("ardureset")) ardureset(outpr);
	}
	
	void writeser(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String rec=req.getParameter("rec");
		commpr.println(rec);
		outpr.println("OK");
		test("writeser> "+rec,"","");
	}
	
	void refresh(PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String rec;
		while ((rec=Receiver.buffer.poll())!=null){outpr.println(rec+"<br/>");test("refresh> "+rec,"","");}
	}
	
	void opencomm(HttpServletRequest req,PrintWriter outpr)
	{
		if (Receiver==null) Receiver=new CReceiver();
		else Receiver.reset();
		String baud=req.getParameter("val");
		int ib=Integer.parseInt(baud);
		if (ib!=0) Bauds=ib;
		Comm=SerialComm.openComm(Port, Bauds, Receiver);
		if (Comm==null) {outpr.println("NOK");}
		else {commpr=Comm.getPrintStream();delay(5000);outpr.println("OK");}
	}

	void closecomm(PrintWriter outpr)
	{
		if (Comm!=null) Comm.closeComm();
		outpr.println("OK");
	}
	
	String getCommResp()
	{
		String rec="NOK";
		try {rec = Receiver.buffer.poll(1,TimeUnit.SECONDS);} 
		catch (InterruptedException e) {}
		if(rec==null) rec="NOK";
		return rec;
	}
	
	void readAna(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String par=req.getParameter("pin");
		char p=par.charAt(0);
		String comcmd="RA"+p;
		commpr.println(comcmd);
		String cresp=getCommResp();
		outpr.println(cresp);
		test("readAna "+par,comcmd,cresp);
	}
	
	void readDig(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String par=req.getParameter("pin");
		String comcmd="RD"+par;
		commpr.println(comcmd);
		String cresp=getCommResp();
		outpr.println(cresp);
		test("readAna "+par,comcmd,cresp);		
	}
	
	void writeDig(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String par=req.getParameter("pin");
		String val=req.getParameter("val");
		String comcmd="WD"+par+"="+val;
		commpr.println(comcmd);		
		String cresp=getCommResp();
		outpr.println(cresp);
		test("writeDig "+par+" "+val,comcmd,cresp);		
	}	
	
	void writeAna(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String par=req.getParameter("pin");
		String val=req.getParameter("val");
		String comcmd="WA"+par+"="+val;
		commpr.println(comcmd);
		String cresp=getCommResp();
		outpr.println(cresp);
		test("writeAna "+par+" "+val,comcmd,cresp);
	}	
	
	void setPin(HttpServletRequest req,PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		String par=req.getParameter("pin");
		String val=req.getParameter("val");
		String comcmd="SP"+par+"="+val;
		commpr.println(comcmd);
		String cresp=getCommResp();
		outpr.println(cresp);
		test("setPin "+par+" "+val,comcmd,cresp);		
	}
	
	void readAll(PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		commpr.println("PA");
		String cresp=getCommResp();
		outpr.println(cresp);
		test("readAll","PA",cresp);
	}	
	
	void readAllDigInp(PrintWriter outpr)
	{
		if (Comm==null) {outpr.println("NOK");return;}
		commpr.println("D");
		String cresp=getCommResp();
		outpr.println(cresp);
		test("readAllDigInp","D",cresp);
	}
	
	void ardureset(PrintWriter outpr)
	{
		Runtime rt=Runtime.getRuntime();
		try {rt.exec("/home/raspduino/RandaReset.sh");} 
		catch (IOException e) {e.printStackTrace();}
		outpr.println("OK");		
	}
	
	
	void test(String cmd,String toComm,String ret)
	{
		System.out.println(cmd+" -> "+toComm+" -> "+ret);
	}
	
	void delay(long t)
	{
	   try {Thread.sleep(t);} catch (InterruptedException e) {}
	}
	
	
	class CReceiver implements CommReceiver
	{
		LinkedTransferQueue <String> buffer=new LinkedTransferQueue();
		
		public void reset(){buffer.clear();}

		@Override
		public void newByte(byte by) {}

		@Override
		public void newRecord(String rec) {
		  buffer.add(rec);	
		}
		
	}
	

}
