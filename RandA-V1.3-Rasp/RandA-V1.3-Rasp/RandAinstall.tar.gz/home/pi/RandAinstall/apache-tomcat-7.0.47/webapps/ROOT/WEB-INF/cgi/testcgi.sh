#!/bin/bash
# Example of CGI with bash script
echo "Content-type: text/html"
echo ""
echo "" 
echo '<html>'
echo '<head></head>'
echo '<body>'
echo '<h2>Test CGI</h2>'
date "+DATE: %m/%d/%Y" 
echo '<p>You can put here any system command</p>'
echo '</body>'
echo '</html>'
exit 0
