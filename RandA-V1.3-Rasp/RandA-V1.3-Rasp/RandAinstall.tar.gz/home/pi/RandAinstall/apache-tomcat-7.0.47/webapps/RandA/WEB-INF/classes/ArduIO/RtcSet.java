package ArduIO;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import RandAClock.Clock;
/**
 * Servlet implementation class RtcSet
 */
@WebServlet("/RtcSet")
public class RtcSet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Date testdate;
	Calendar tclk;
	String alarm[]={"m","9","13","40","y"};
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RtcSet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
 //     testdate=new Date(System.currentTimeMillis());
 //     tclk=Calendar.getInstance();
 //     tclk.setTime(testdate);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter outpr=new PrintWriter(response.getWriter());
		String cmd=request.getParameter("cmd");
		if (cmd.equalsIgnoreCase("getClock")) getclock(outpr);
		if (cmd.equalsIgnoreCase("setClock")) setclock(request,outpr);
		if (cmd.equalsIgnoreCase("getSysClock")) getsysclock(outpr);
		if (cmd.equalsIgnoreCase("setSysClock")) setsysclock(request,outpr);
		if (cmd.equalsIgnoreCase("getAlarm")) getalarm(outpr);
		if (cmd.equalsIgnoreCase("setAlarm")) setalarm(request,outpr);
		if (cmd.equalsIgnoreCase("cancAlarm")) cancalarm(outpr);
		if (cmd.equalsIgnoreCase("shutdown")) shutdown(outpr);
	}

	void getclock(PrintWriter outpr)
	{
	    String clk=Clock.getJsonDate(); 	
        outpr.println(clk);
	}
	
	void getsysclock(PrintWriter outpr)
	{
//		testdate=new Date(System.currentTimeMillis());
		tclk=new GregorianCalendar();
		int fd=1-tclk.getFirstDayOfWeek();
//		tclk.setTime(testdate);
		int year=tclk.get(Calendar.YEAR)-2000;
		String clk="["+year+","+(tclk.get(Calendar.MONTH)+1)+","+tclk.get(Calendar.DAY_OF_MONTH)+","+
		                        tclk.get(Calendar.HOUR_OF_DAY)+","+tclk.get(Calendar.MINUTE)+","+
				                (tclk.get(Calendar.DAY_OF_WEEK)+fd)+"]";	
		outpr.println(clk);
	}
	
	void setsysclock(HttpServletRequest req,PrintWriter outpr)
	{
		String value=req.getParameter("val");
		String v[]=value.split(",");
		tclk.set(Calendar.YEAR, Integer.parseInt(v[0])+2000);
		tclk.set(Calendar.MONTH, Integer.parseInt(v[1])-1);
		tclk.set(Calendar.DAY_OF_MONTH, Integer.parseInt(v[2]));
		tclk.set(Calendar.HOUR_OF_DAY, Integer.parseInt(v[3]));
		tclk.set(Calendar.MINUTE, Integer.parseInt(v[4]));
		String cmd="date -s \""+v[2]+"/"+v[1]+"/20"+v[0]+" "+v[3]+":"+v[4]+":00\"";
		Process proc;
		int ret;
		try {
			  proc=Runtime.getRuntime().exec(cmd);
			  proc.waitFor();
			  ret=proc.exitValue();
		    } 
		catch (IOException e) {e.printStackTrace();} 
		catch (InterruptedException e) {e.printStackTrace();}		
	}
	
	void setclock(HttpServletRequest req,PrintWriter outpr)
	{
		String value=req.getParameter("val");
		String v[]=value.split(",");
		int y=Integer.parseInt(v[0])+2000;
		int m=Integer.parseInt(v[1]);
		int d=Integer.parseInt(v[2]);
		int h=Integer.parseInt(v[3]);
		int min=Integer.parseInt(v[4]);
		Clock.setDate(y,m,d,h,min);
	}
	
	void getalarm(PrintWriter outpr)
	{
		String al=Clock.getJsonAlarm();
//		outpr.println("[\""+alarm[0]+"\","+alarm[1]+","+alarm[2]+","+alarm[3]+",\""+alarm[4]+"\"]");
		outpr.println(al);
	}
	
	void setalarm(HttpServletRequest req,PrintWriter outpr)
	{
		String val=req.getParameter("val");
		String sval[]=val.split(",");
		if (sval==null) return;
		alarm[0]=sval[0];
		if (sval[1].contentEquals("*")) alarm[1]="-1"; else alarm[1]=sval[1];
		if (sval[2].contentEquals("*")) alarm[2]="-1"; else alarm[2]=sval[2];
		alarm[3]=sval[3];
		boolean fw=false; 
		if (alarm[0].contentEquals("w")) fw=true;
		Clock.setAlarm(Integer.parseInt(alarm[1]),Integer.parseInt(alarm[2]),Integer.parseInt(alarm[3]), fw);
	}
	
	void cancalarm(PrintWriter outpr)
	{
		Clock.resetAlarm();
		alarm[4]="n";
	}
	
	void shutdown(PrintWriter outpr)
	{
		Runtime rt=Runtime.getRuntime();
		try {rt.exec("sudo shutdown -h now");} 
		catch (IOException e) {e.printStackTrace();}
		outpr.println("OK");
	}
	
	
	

}
