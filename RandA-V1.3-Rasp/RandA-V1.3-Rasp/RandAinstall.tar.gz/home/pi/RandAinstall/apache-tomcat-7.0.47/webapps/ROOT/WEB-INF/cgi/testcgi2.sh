#!/bin/bash
# Example of CGI with bash script
# Example with input parameters management.
# Parameters are included in environment variable QUERY_STRING
# Format: par1=val1&par2=val&...

#Parameters scanning 
qstring=$QUERY_STRING 
qstring=${qstring//&/ }        #Substute & with space
read -r -a par <<< "$qstring"  #Scan couples par=val to array par
for p in ${par[@]}; do         #For each array element p:
pn=${p%=*}                     #pn contains parameter name
pv=${p#*=}                     #pv contains parameter value

if [ $pn = "name" ]; then
name=$pv
fi

done

# html page replying

echo "Content-type: text/html"
echo ""
echo "" 
echo '<html>'
echo '<head></head>'
echo '<body>'
echo '<h2>Test CGI</h2>'
date "+DATE: %m/%d/%Y" 
echo '<p>Good morning '$name '</p>'
echo '<p></p>'
echo '<p>QUERY_STRING: '$QUERY_STRING '</p>'
echo 'Note that query string is in URLencode format.'
echo 'If you use space or special characters you have to decode parameters'
echo '<p></p>'
echo '<p> testcgi2.sh listing </p>'
echo '<pre>'
# filter for < and > to list this code on html page
sed 's/</\&lt/g' testcgi2.sh | sed 's/>/\&gt/g' -    
echo '</pre>'
echo '</body>'
echo '</html>'
exit 0
