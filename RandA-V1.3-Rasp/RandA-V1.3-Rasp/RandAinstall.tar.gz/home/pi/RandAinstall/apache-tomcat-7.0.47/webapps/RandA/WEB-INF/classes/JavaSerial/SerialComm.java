package JavaSerial;

import gnu.io.*;

import java.util.concurrent.*;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JOptionPane;

import java.util.*;
/**
 * Gestione della libreria RXTXComm.jar
 * Ha bisogno anche della ddl rxtxSerial.ddl 
 * (va collocata nella directory di lavoro oppure in Java )
 * Va utilizzata insieme all'interfaccia CommReceiver
 * Metodi statici per:<br>
 * - Avere l'elenco delle porte disponibili<br>
 * - Aprire una porta seriale con messaggio di status<br>
 * - Verificare se una porta esiste.
 * - Metodo d'istanza per chiudere una comunicazione seriale
 * - Mostra status su MessageDialog
 * - Get caratteristiche e status (codice e messaggio)
 * 
 * 
 * @author Daniele
 */
public class SerialComm
{
	public static final int COMM_INUSE=-1; 
	public static final int COMM_UNKNOWN=-2;
	public static final int COMM_NOSER=-3;
	public static final int COMM_UNOP=-4;
	public static final int COMM_NOOUT=-5;
	public static final int COMM_NOREADER=-6;
	public static final int COMM_OK=0;
	
	public static boolean errorShow=false;
	
	private static class Error
	{
		static int cod;
		static String mess;
	}
	
	private SerialPort comm;
	private SerialReader sreader;
	private PrintStream prs;
	
	
	/**
	 * Il costruttore non viene utilizzato da solo. Ma soltanto dai metodi 
	 * openComm().
	 * Una istanza di questa classe pu� essere usata per chiudere la 
	 * comunicazione. Infatti � l'unico modo per chiudere in maniera ordinata.
	 * @param c
	 * @param sr
	 * @param pr
	 */
	private SerialComm(SerialPort c,SerialReader sr,PrintStream pr)
	{
		comm=c;
		sreader=sr;
		prs=pr;
	}

	
	public SerialPort getPort(){return comm;}
	public PrintStream getPrintStream(){return prs;}
	public int getBauds(){return comm.getBaudRate();}
	public int getBits(){return comm.getDataBits();}
	public int getParity(){return comm.getParity();}
	public int getStopbits(){return comm.getStopBits();}
	
	public int getErrorCode(){return SerialComm.Error.cod;}
	public String getErrorMess(){return SerialComm.Error.mess;}
	
	/**
	 * Chiude l'istanza SerialComm
	 */
	public void closeComm()
	{
		prs.flush();
		prs.close();
		sreader.closeThread();
		comm.close();
	}

/**
 * Ritorna un vettore con tutte le porte disponibili (e libere)	
 * @return
 */
  static public Vector<CommPortIdentifier> getFreeComm()
  {
      CommPortIdentifier commId=null;
      Vector<CommPortIdentifier> vcomm=new Vector();
      Enumeration<CommPortIdentifier> comms=CommPortIdentifier.getPortIdentifiers();
      while(comms.hasMoreElements())
      {
    	  commId=comms.nextElement();
          if (commId.getPortType()==CommPortIdentifier.PORT_SERIAL)
          if (!commId.isCurrentlyOwned()) vcomm.add(commId);
       }
	   return vcomm;
  }
	   
  static public Vector<String> getFreeCommName()
  {
       CommPortIdentifier commId=null;
       Vector<String> svcomm=new Vector();
       Vector<CommPortIdentifier> vcomm=getFreeComm();
       for (int i=0;i<vcomm.size();i++) {svcomm.add(vcomm.get(i).getName());}
       return svcomm;
  }

 /**
  * Verifica l'esistenza di una porta di un certo nome   
  * @param name
  * @return
  */
   static public boolean exist(String name)
   {
       CommPortIdentifier commId=null;
       try{commId=CommPortIdentifier.getPortIdentifier(name);}
       catch(NoSuchPortException e){return false;}
       return true;
   }


 /**
  * Apre una porta seriale e restituisce una nuova istanza SerialComm.
  * Inoltre starts un thread che riceve i byte ed attiva i metodi newByte(b) e
  * newRecord(r) dell'oggetto receiver passato come parametro.
  * L'oggetto receiver inplementa l'interfaccia CommReceiver .
  * Il metodo newByte(byte b) viene attivato ad ogni byte ricevuto; mentre il metodo
  * newRecord(String r) viene attivato quando viene completato un record con il
  * ricevimento di un lf e/o cr.
  * Restituisce anche un oggetto PrintStream.    
  * @param name		nome della seriale
  * @param bauds	velocit� in bauds
  * @param receiver	oggetto che implementa l'interfaccia CommReceiver
  * @return			Una istanza SerialComm
  */
   static public SerialComm openComm(String name,int bauds,CommReceiver receiver,int databits,int stopbits,int parity)
   {
       CommPort comm=null;
       SerialPort scomm=null;
       CommPortIdentifier commId=null;
       PrintStream pr=null;
       SerialComm sc=null;
       try{commId=CommPortIdentifier.getPortIdentifier(name);}
       catch(NoSuchPortException e){ErrMess(COMM_UNKNOWN,name);return null;}
       try {comm=commId.open(Thread.currentThread().getClass().getName(),2000);}
       catch(PortInUseException ex) {ErrMess(COMM_INUSE,name);return null;}
       if (!(comm instanceof SerialPort)){ErrMess(COMM_NOSER,name);return null;}
       scomm=(SerialPort)comm;
       try {scomm.setSerialPortParams(bauds,databits,stopbits,parity);} 
       catch (UnsupportedCommOperationException e)
             {scomm.close();ErrMess(COMM_UNOP,name);return null;}
       try {pr=new PrintStream(scomm.getOutputStream());}
       catch (IOException e)
             {scomm.close();ErrMess(COMM_NOOUT,e.getMessage());return null;}        
       SerialReader reader=new SerialReader(scomm,receiver);
       if (reader==null){ErrMess(COMM_NOREADER,name);return null;}
       reader.start(); 
       sc=new SerialComm(scomm,reader,pr);
       ErrMess(COMM_OK,name);
       return sc;
   }
   
   static public SerialComm openComm(String name,int bauds,CommReceiver receiver)
   {
	   return openComm(name,bauds,receiver,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
   }
   

   private static class SerialReader extends Thread
   {
	   CommReceiver receiver;
       SerialPort comm=null;
       InputStream in;
       int by,oldby;
       byte[] buffer = new byte[4096];
       boolean stop=false;
 
       SerialReader(SerialPort comm,CommReceiver receiver)
       {
           super();
           this.comm=comm;
           try{comm.enableReceiveTimeout(500);}
                                 catch(Exception e){e.printStackTrace();}
           try {in=comm.getInputStream();}
                                 catch(IOException e){e.printStackTrace();}
           this.receiver=receiver;
       }

       public void closeThread(){stop=true;}

       public void run()
       {
    	   int n=0;
            try
            {
              while ( !stop )
              {
                by=this.in.read();
                if(by<0) {continue;}
                receiver.newByte((byte)by);
                buffer[n]=(byte)by;
                if ((n==0)&(by=='\n')) continue;
                if (by=='\r') oldby=by; 
                if ((by=='\n')&(oldby=='\r')) 
                {String rec=new String(buffer,0,n+1);receiver.newRecord(rec);n=0;oldby=0;continue;}
                n++;
                if (n>=buffer.length-2) 
                {String rec=new String(buffer,0,n+1);receiver.newRecord(rec);n=0;oldby=0;continue;}	
              }
              in.close();
            }
            catch ( IOException e ){ e.printStackTrace();}
       }
   }

   static private void ErrMess(int err,String txt)
   {
	  Error.cod=err; 
	  switch(err)
	  {
	    case COMM_UNKNOWN: Error.mess=txt+" port doesn't exist !";break;
	    case COMM_INUSE: Error.mess=txt+" port already in use. Close that application!";break;
	    case COMM_NOSER: Error.mess=txt+" not serial port!";break;
	    case COMM_UNOP: Error.mess=txt;break;
	    case COMM_NOOUT: Error.mess=txt;break;
	    case COMM_NOREADER: Error.mess="Error on creating reader thread";break;
	    case COMM_OK: Error.mess=txt+" created!";break;
	  }
      if (errorShow) ShowStatus();
   }
   
   static public void ShowStatus()
   {JOptionPane.showMessageDialog(null, Error.mess);}


}
