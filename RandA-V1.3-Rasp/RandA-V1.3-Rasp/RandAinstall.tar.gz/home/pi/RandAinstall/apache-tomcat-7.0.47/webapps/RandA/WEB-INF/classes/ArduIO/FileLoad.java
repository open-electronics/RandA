package ArduIO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JavaSerial.SerialComm;

/**
 * Servlet implementation class FileLoad
 */
@WebServlet("/FileLoad")
public class FileLoad extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	Properties Prop;
	String Root1,Root2;
	File Froot1,Froot2;
	
	String AvrdudeProg="";
	String AvrCmd;
	String ArduPort="";
	
	File lastPath;
	
	FileFilter filter;
	
	String sketch;
	
	String loadErr=null;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileLoad() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
       Prop=new Properties();
       
//       InputStream inputStream = getClass().getClassLoader().getResourceAsStream("RaspDuino.properties");

       InputStream inputStream =config.getServletContext().getResourceAsStream("RaspDuino.properties");
       
       try {Prop.load(inputStream);}
       catch (FileNotFoundException e) {e.printStackTrace();return;} 
       catch (IOException e) {e.printStackTrace();return;}
       Root1=Prop.getProperty("SketchDir").trim(); 
       Root2=Prop.getProperty("WorkDir").trim(); 
       Froot1=new File(Root1);
       Froot2=new File(Root2);
       filter=new FFilter();
       
       AvrdudeProg=Prop.getProperty("Avrdude");
       String avrdconf=Prop.getProperty("AvrdudeConf");
       ArduPort=Prop.getProperty("ArduinoPort");
       AvrCmd=" -C "+avrdconf+" -p atmega328p"+" -P "+ArduPort+" -c arduino -b 115200 -D -V -q -U flash:w:";
       File avrprg=new File(AvrdudeProg);
       File avrcnf=new File(avrdconf);
       if (!avrprg.exists()) {loadErr="Avrdude program file not found!";return;}
       if (!avrprg.exists()) loadErr="Avrdude configuration file not found!";
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter outpr=new PrintWriter(response.getWriter());
		String cmd=request.getParameter("cmd");
		if (cmd.equalsIgnoreCase("setroot")) setroot(outpr,request);		
		if (cmd.equalsIgnoreCase("list")) dirfiles(outpr,request);		
		if (cmd.equalsIgnoreCase("descr")) descrfiles(outpr,request);
		if (cmd.equalsIgnoreCase("savedescr")) savedescr(outpr,request);
		if (cmd.equalsIgnoreCase("arduinoload")) arduinoLoad(outpr,request);
		if (cmd.equalsIgnoreCase("avrdudecheck")) avrdudecheck(outpr);

	
	}
	
	void avrdudecheck(PrintWriter outpr)
	{
		if (loadErr!=null) outpr.println(loadErr);
		else outpr.println("OK");
	}
	
	int AvrCommand(String avrprog,String preavrcmd, String sketch)
	{
		int ret=-1;
//		String cmd=avrprog+preavrcmd+sketch+":i";
		String cmd="/home/raspduino/AUpload.sh "+sketch;
//		System.out.println(cmd);return 0;
		
		Process proc;
		try {
			  proc=Runtime.getRuntime().exec(cmd);
			  proc.waitFor();
			  ret=proc.exitValue();
		    } 
		catch (IOException e) {e.printStackTrace();} 
		catch (InterruptedException e) {e.printStackTrace();}
		return ret;
		
	}
	
	void arduinoLoad(PrintWriter outpr,HttpServletRequest request)
	{
//		if (loadErr!=null) {outpr.println(loadErr);return;}
		loadErr=null;
		if (!checkPort()) {outpr.println(loadErr);return;}
		String sketch=lastPath+File.separator+request.getParameter("sketch");
		File fsketch=new File(sketch);
		if (!fsketch.exists()) loadErr="Sketch file not found! "+sketch;
        if (fsketch.isDirectory()) loadErr="No Sketch ! "+sketch;
		if (loadErr!=null) {outpr.println(loadErr);return;}
		int ret=AvrCommand(AvrdudeProg,AvrCmd,sketch);
		if (ret==0) loadErr="OK sketch loaded: "+sketch;
		else loadErr="NOK ERR "+ret;
		outpr.println(loadErr);
	}
	
	boolean checkPort()
	{
		boolean ret=SerialComm.exist(ArduPort);
		if (!ret) loadErr="Arduino not connected!";
		return ret;
	}
	
	void setroot(PrintWriter outpr,HttpServletRequest request)
	{
		String root=request.getParameter("dir");
		if (root.equalsIgnoreCase("0")) {outpr.println(Froot1.getName());lastPath=Froot1.getParentFile();}	
		if (root.equalsIgnoreCase("1")) {outpr.println(Froot2.getName());lastPath=Froot2.getParentFile();}		
	}
	
	void listfiles(PrintWriter outpr, String dir)
	{
		File froot;
		if (dir.equalsIgnoreCase("/")) {lastPath=lastPath.getParentFile();}
		else {if(dir.startsWith("/")) {dir=dir.substring(1);} lastPath=new File(lastPath,dir);}
		froot=lastPath;
		File flist[]=froot.listFiles(filter);
		String fn="";
		outpr.print("[");
		String pth=froot.getPath();
		if (!pth.contentEquals(Root1))
			if (!pth.contentEquals(Root2)) 
				outpr.print("\"/\",");
		for (int i=0;i<flist.length;i++)
		{
			if (flist[i].isDirectory()) fn="/"+flist[i].getName();
			else  fn=flist[i].getName();
			if (i==flist.length-1) fn="\""+fn+"\"";
			else fn="\""+fn+"\",";
			outpr.print(fn);
//			System.out.print(fn);
		}
		outpr.println("]");
	}
	
	void dirfiles(PrintWriter outpr,HttpServletRequest request)
	{
		String dir=request.getParameter("dir");
		listfiles(outpr,dir);
	}
	
	
	void descrfiles(PrintWriter outpr,HttpServletRequest request)
	{
		File froot=lastPath;
		File flist[]=froot.listFiles(filter);
		outpr.print("[");
		if ((froot.compareTo(Froot1)!=0)&(froot.compareTo(Froot2)!=0)) outpr.print("\"\",");
		for (int i=0;i<flist.length;i++)
		{
			String name=flist[i].getName();
			int p=name.indexOf('.');
			if (p>=0) name=name.substring(0, p);
			String descr="";
			if (!name.startsWith("/")) 
			 {
				File fd=new File(froot,name+".descr");
			    if (fd.exists()) descr=getContent(fd);
			 }
			if (i==flist.length-1) descr="\""+descr+"\"";
			else descr="\""+descr+"\",";
			outpr.print(descr);
//			System.out.print(descr);
		}
		outpr.println("]");
	}
	
	String getContent(File f)
	{
		String ret="";
		FileReader fr;
		try {fr=new FileReader(f);}
		catch (FileNotFoundException ex) {return ret;}
		BufferedReader rd=new BufferedReader(fr);
		String rec;
		try
		{while((rec=rd.readLine())!=null) 
//		  {if (ret.length()==0) ret=rec; else ret=ret+"<br/>"+rec;} rd.close();}
		  {if (ret.length()==0) ret=rec; else ret=ret+"\\n"+rec;} rd.close();}
		catch(IOException ex){return ret;}
		return ret;
	}
	
	void savedescr(PrintWriter outpr,HttpServletRequest request)
	{
		File froot=lastPath;
        String sk=request.getParameter("file");
        if (sk==null) return;
        if (sk.length()==0)return;
		String txt=request.getParameter("descr");
		if (txt==null) return;
		int p=sk.indexOf('.');
		String name="";
		if (p>=0)  name=sk.substring(0, p);
		File fd=new File(froot,name+".descr");
		try 
		{
			PrintStream pf=new PrintStream(fd);
			pf.print(txt);
			pf.close();
		} 
		catch (FileNotFoundException e) {	e.printStackTrace();}
		outpr.print("OK");
	}
	
	class FFilter implements FileFilter
	{

		public boolean accept(File arg0)
		{
			int p=arg0.getName().lastIndexOf('.');p++;
		    String ext=arg0.getName().substring(p);
			if (arg0.isDirectory()|ext.equalsIgnoreCase("hex")) return true;
			return false;
		}
		
	}

}
