#!/bin/bash
/usr/local/bin/gpio -g mode 24 down
/usr/local/bin/gpio -g wfi 24 rising
echo "Shutdown" 
sudo shutdown -h now